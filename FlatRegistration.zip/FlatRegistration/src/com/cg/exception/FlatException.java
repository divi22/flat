package com.cg.exception;

public class FlatException extends Exception{

	public FlatException() {
		super("some error occured...");
		}
	
		public FlatException(String str)
		{
		super(str);	
		}
}
