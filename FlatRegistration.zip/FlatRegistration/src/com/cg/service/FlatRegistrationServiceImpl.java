package com.cg.service;

import java.util.ArrayList;
import java.util.Map;

import com.cg.dao.FlatRegistrationDaoImpl;
import com.cg.dao.IFlatRegistrationDao;
import com.cg.dto.FlatRegistrationDTO;
import com.cg.exception.FlatException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService{

	IFlatRegistrationDao dao;
	DataValidator validator; 
	
	public FlatRegistrationServiceImpl()
	{
		dao= new FlatRegistrationDaoImpl();
		validator= new DataValidator();
	}
	
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatException {
		if(!validator.validateFlatType(flat.getFlatType()))
		{
			throw new FlatException("flat type should be either 1 or 2");
		}
		else
		{
		int registrationId= (int) (Math.random()*10000);
		flat.setRegistrationId(registrationId);;
		return dao.registerFlat(flat);
		}
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatException {
		// TODO Auto-generated method stub
		return dao.getAllOwnerIds();
	}

	@Override
	public Map<Integer, FlatRegistrationDTO> getRegistrationDetails() throws FlatException {
		// TODO Auto-generated method stub
		return dao.getRegistrationDetails();
	}

}
