package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.cg.dto.FlatOwner;
import com.cg.dto.FlatRegistrationDTO;
import com.cg.exception.FlatException;

public class FlatRegistrationDaoImpl implements IFlatRegistrationDao {

	static Map<Integer,FlatOwner> owners= new HashMap<>();
	static
	{
		owners.put(1,new FlatOwner(1,"Vaishaili","9769251256"));
		owners.put(2,new FlatOwner(2,"Pradyna","9769456987"));
		owners.put(3,new FlatOwner(3,"Rifat","9769445687"));
	}
	
	
	Map<Integer,FlatRegistrationDTO> flatDetails= new HashMap<>();
	
	
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatException {
		if(owners.containsKey(flat.getFlatOwnerId()))
		{
			flatDetails.put(flat.getRegistrationId(),flat);
			return flat;	
		}
		else
		{
			throw new FlatException("OWner ID does not exist");
		}		
	
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatException {
		
		Collection<Integer> list=owners.keySet();
		List<Integer> ownerList=new ArrayList<>(list);
		return (ArrayList<Integer>) ownerList;
	}
	
	public Map<Integer,FlatRegistrationDTO>  getRegistrationDetails() throws FlatException
	{
		return flatDetails;
	}

}
