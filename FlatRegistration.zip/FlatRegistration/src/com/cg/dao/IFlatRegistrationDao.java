package com.cg.dao;

import java.util.ArrayList;
import java.util.Map;

import com.cg.dto.FlatRegistrationDTO;
import com.cg.exception.FlatException;

public interface IFlatRegistrationDao {

	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatException;
	
	ArrayList<Integer> getAllOwnerIds() throws FlatException;
	
	Map<Integer,FlatRegistrationDTO>  getRegistrationDetails() throws FlatException;
}
